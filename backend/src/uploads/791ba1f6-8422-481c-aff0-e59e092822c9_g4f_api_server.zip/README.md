# G4F API Server Documentation

This API server provides access to AI models through the g4f library, allowing you to interact with various AI models via RESTful API endpoints.

## Features

- **Multiple AI Models**: Access to various models like GPT-3.5, GPT-4, Claude, and Gemini
- **Session Management**: Create, list, update, and delete chat sessions
- **History Management**: Store and retrieve conversation history
- **Customizable Settings**: Adjust model parameters like temperature and response length

## Setup Instructions

### Prerequisites

- Python 3.8 or higher
- Flask
- g4f library

### Installation

1. Install the required dependencies:

```bash
pip install flask flask-cors g4f
```

2. Run the API server:

```bash
python app.py
```

By default, the server runs on port 5000. You can change this by setting the `PORT` environment variable:

```bash
PORT=8080 python app.py
```

## API Endpoints

### Health Check

- **GET /api/health**
  - Check if the API server is running
  - Response: `{"success": true, "status": "healthy", "version": "1.0.0", "timestamp": "..."}`

### Models

- **GET /api/models**
  - Get a list of available AI models
  - Response: `{"success": true, "models": [...]}`

### Sessions

- **GET /api/sessions**
  - List all active sessions
  - Response: `{"success": true, "sessions": [...]}`

- **POST /api/sessions**
  - Create a new session
  - Request body: `{"settings": {"model": "gpt-4o-mini", "temperature": 0.7, ...}}`
  - Response: `{"success": true, "session_id": "...", "settings": {...}}`

- **GET /api/sessions/{session_id}**
  - Get information about a specific session
  - Response: `{"success": true, "session_id": "...", "created_at": "...", ...}`

- **DELETE /api/sessions/{session_id}**
  - Delete a session
  - Response: `{"success": true, "message": "Session ... deleted"}`

### Session Settings

- **PUT /api/sessions/{session_id}/settings**
  - Update session settings
  - Request body: `{"model": "gpt-4", "temperature": 0.8, ...}`
  - Response: `{"success": true, "settings": {...}}`

### Session History

- **GET /api/sessions/{session_id}/history**
  - Get the conversation history for a session
  - Response: `{"success": true, "history": [...]}`

- **DELETE /api/sessions/{session_id}/history**
  - Clear the conversation history for a session
  - Response: `{"success": true, "message": "History cleared"}`

### Chat

- **POST /api/sessions/{session_id}/chat**
  - Send a message and get a response
  - Request body: `{"message": "Hello, how are you?"}`
  - Response: `{"success": true, "response": "...", "history": [...]}`

## Example Usage

### Creating a New Session

```bash
curl -X POST http://185.232.204.20:5000/api/sessions \
  -H "Content-Type: application/json" \
  -d '{"settings": {"model": "gpt-4o-mini", "temperature": 0.7}}'
```

### Sending a Message

```bash
curl -X POST http://185.232.204.20:5000/api/sessions/YOUR_SESSION_ID/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello, how are you today?"}'
```

### Changing the Model

```bash
curl -X PUT http://185.232.204.20:5000/api/sessions/YOUR_SESSION_ID/settings \
  -H "Content-Type: application/json" \
  -d '{"model": "gpt-4"}'
```

### Getting Conversation History

```bash
curl -X GET http://185.232.204.20:5000/api/sessions/YOUR_SESSION_ID/history
```

## Error Handling

All endpoints return appropriate HTTP status codes and error messages:

- 200: Success
- 400: Bad request (invalid parameters)
- 404: Resource not found
- 500: Server error

Error responses have the format:

```json
{
  "success": false,
  "error": "Error message"
}
```

## Testing

A test script is included to verify all API endpoints:

```bash
python test_api.py http://185.232.204.20:5000/api
```

## Security Considerations

- This API server does not include authentication
- For production use, consider adding API keys or other authentication methods
- The server binds to all interfaces (0.0.0.0) by default
