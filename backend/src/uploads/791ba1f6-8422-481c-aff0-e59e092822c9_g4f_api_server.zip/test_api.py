#!/usr/bin/env python3
"""
Test script for G4F API Server
This script tests the various endpoints of the G4F API Server
"""

import requests
import json
import time
import sys

# Base URL for API - change this to your server address
BASE_URL = "http://localhost:5000/api"

def test_health_check():
    """Test the health check endpoint"""
    print("\n=== Testing Health Check ===")
    response = requests.get(f"{BASE_URL}/health")
    print(f"Status Code: {response.status_code}")
    print(json.dumps(response.json(), indent=2))
    assert response.status_code == 200
    assert response.json()["success"] == True
    print("✅ Health check passed")

def test_get_models():
    """Test getting available models"""
    print("\n=== Testing Get Models ===")
    response = requests.get(f"{BASE_URL}/models")
    print(f"Status Code: {response.status_code}")
    print(json.dumps(response.json(), indent=2))
    assert response.status_code == 200
    assert response.json()["success"] == True
    assert len(response.json()["models"]) > 0
    print("✅ Get models passed")

def test_create_session():
    """Test creating a new session"""
    print("\n=== Testing Create Session ===")
    payload = {
        "settings": {
            "model": "gpt-3.5-turbo",
            "temperature": 0.5,
            "max_tokens": 500
        }
    }
    response = requests.post(f"{BASE_URL}/sessions", json=payload)
    print(f"Status Code: {response.status_code}")
    print(json.dumps(response.json(), indent=2))
    assert response.status_code == 200
    assert response.json()["success"] == True
    assert "session_id" in response.json()
    session_id = response.json()["session_id"]
    print(f"✅ Create session passed, session_id: {session_id}")
    return session_id

def test_list_sessions():
    """Test listing all sessions"""
    print("\n=== Testing List Sessions ===")
    response = requests.get(f"{BASE_URL}/sessions")
    print(f"Status Code: {response.status_code}")
    print(json.dumps(response.json(), indent=2))
    assert response.status_code == 200
    assert response.json()["success"] == True
    assert "sessions" in response.json()
    print("✅ List sessions passed")

def test_get_session_info(session_id):
    """Test getting session information"""
    print(f"\n=== Testing Get Session Info for {session_id} ===")
    response = requests.get(f"{BASE_URL}/sessions/{session_id}")
    print(f"Status Code: {response.status_code}")
    print(json.dumps(response.json(), indent=2))
    assert response.status_code == 200
    assert response.json()["success"] == True
    assert response.json()["session_id"] == session_id
    print("✅ Get session info passed")

def test_update_session_settings(session_id):
    """Test updating session settings"""
    print(f"\n=== Testing Update Session Settings for {session_id} ===")
    payload = {
        "model": "gpt-4o-mini",
        "temperature": 0.8,
        "max_tokens": 2000
    }
    response = requests.put(f"{BASE_URL}/sessions/{session_id}/settings", json=payload)
    print(f"Status Code: {response.status_code}")
    print(json.dumps(response.json(), indent=2))
    assert response.status_code == 200
    assert response.json()["success"] == True
    assert response.json()["settings"]["model"] == "gpt-4o-mini"
    assert response.json()["settings"]["temperature"] == 0.8
    print("✅ Update session settings passed")

def test_chat(session_id):
    """Test sending a message and getting a response"""
    print(f"\n=== Testing Chat for {session_id} ===")
    payload = {
        "message": "Hello, how are you today?"
    }
    response = requests.post(f"{BASE_URL}/sessions/{session_id}/chat", json=payload)
    print(f"Status Code: {response.status_code}")
    print(json.dumps(response.json(), indent=2))
    assert response.status_code == 200
    assert response.json()["success"] == True
    assert "response" in response.json()
    print("✅ Chat passed")

def test_get_history(session_id):
    """Test getting session history"""
    print(f"\n=== Testing Get History for {session_id} ===")
    response = requests.get(f"{BASE_URL}/sessions/{session_id}/history")
    print(f"Status Code: {response.status_code}")
    print(json.dumps(response.json(), indent=2))
    assert response.status_code == 200
    assert response.json()["success"] == True
    assert "history" in response.json()
    assert len(response.json()["history"]) > 0
    print("✅ Get history passed")

def test_clear_history(session_id):
    """Test clearing session history"""
    print(f"\n=== Testing Clear History for {session_id} ===")
    response = requests.delete(f"{BASE_URL}/sessions/{session_id}/history")
    print(f"Status Code: {response.status_code}")
    print(json.dumps(response.json(), indent=2))
    assert response.status_code == 200
    assert response.json()["success"] == True
    
    # Verify history is cleared
    response = requests.get(f"{BASE_URL}/sessions/{session_id}/history")
    assert len(response.json()["history"]) == 0
    print("✅ Clear history passed")

def test_delete_session(session_id):
    """Test deleting a session"""
    print(f"\n=== Testing Delete Session for {session_id} ===")
    response = requests.delete(f"{BASE_URL}/sessions/{session_id}")
    print(f"Status Code: {response.status_code}")
    print(json.dumps(response.json(), indent=2))
    assert response.status_code == 200
    assert response.json()["success"] == True
    
    # Verify session is deleted
    response = requests.get(f"{BASE_URL}/sessions/{session_id}")
    assert response.status_code == 404
    print("✅ Delete session passed")

def run_all_tests():
    """Run all tests"""
    try:
        test_health_check()
        test_get_models()
        session_id = test_create_session()
        test_list_sessions()
        test_get_session_info(session_id)
        test_update_session_settings(session_id)
        test_chat(session_id)
        test_get_history(session_id)
        test_clear_history(session_id)
        test_delete_session(session_id)
        print("\n✅ All tests passed!")
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        BASE_URL = sys.argv[1]
    print(f"Testing API at {BASE_URL}")
    run_all_tests()
